def aggregator_private_attrs():
    return {}

aggregator_kwargs = {}